<#
.SYNOPSIS
    Vérifie qu'une configuration multi-squads est correcte avant mise en prod.

.DESCRIPTION
    Tests réalisés (sans envoyer de mail) :
      1. Fichier parametres_globaux.xlsx présent et lisible
      2. Toutes les clés globales attendues présentes
      3. Au moins une squad détectée
      4. Pour chaque squad : fichier xlsm présent et lisible
      5. Pour chaque squad : fusion config globale + locale -> toutes les clés obligatoires présentes
      6. Connectivité SMTP (Test-NetConnection sur le port)
      7. Pour chaque squad : au moins 1 membre actif Dev et 1 membre actif PO

    Code de sortie : 0 si tout OK, 1 si au moins un test KO.

.PARAMETER DossierRacine
    Chemin racine multi-squads
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string]$DossierRacine
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ClesGlobalesAttendues = @(
    'ServeurSMTP', 'PortSMTP', 'SMTP_UseTLS', 'SMTP_UseSSL',
    'SujetAnnonce', 'SujetRappel', 'SujetAlerte',
    'EmailsAlerteOrchestrateur', 'EmailExpediteurOrchestrateur'
)

$ClesObligatoiresFusion = @(
    'NomSquad', 'EmailExpediteur', 'NomExpediteur',
    'ServeurSMTP', 'PortSMTP', 'SMTP_UseTLS', 'SMTP_UseSSL',
    'ResponsableDev', 'ResponsablePO',
    'SujetAnnonce', 'SujetRappel', 'SujetAlerte'
)

$nbOk = 0
$nbKo = 0

function Test-Result {
    Param([string]$Label, [bool]$Ok, [string]$Detail = "")
    if ($Ok) {
        Write-Host "  [OK]  $Label" -ForegroundColor Green
        if ($Detail) { Write-Host "        $Detail" -ForegroundColor DarkGray }
        $script:nbOk++
    } else {
        Write-Host "  [KO]  $Label" -ForegroundColor Red
        if ($Detail) { Write-Host "        $Detail" -ForegroundColor Yellow }
        $script:nbKo++
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " TEST CONFIGURATION SUIVI D'EXPLOITATION" -ForegroundColor Cyan
Write-Host " Dossier racine : $DossierRacine" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# 0. Module ImportExcel
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Write-Host "Installation du module ImportExcel..." -ForegroundColor Yellow
    Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber
}
Import-Module ImportExcel

# 1. Fichiers de base
Write-Host "[1] Structure de dossiers" -ForegroundColor Cyan
Test-Result "DossierRacine existe" (Test-Path $DossierRacine) $DossierRacine

$dossierConfig  = Join-Path $DossierRacine "_config"
$dossierLogs    = Join-Path $DossierRacine "_logs"
$dossierScripts = Join-Path $DossierRacine "_scripts"
$fichierGlobal  = Join-Path $dossierConfig "parametres_globaux.xlsx"

Test-Result "_config\ existe" (Test-Path $dossierConfig)
Test-Result "_scripts\ existe" (Test-Path $dossierScripts)
Test-Result "parametres_globaux.xlsx présent" (Test-Path $fichierGlobal) $fichierGlobal
if (-not (Test-Path $dossierLogs)) {
    Write-Host "  [INFO] _logs\ sera créé au premier run" -ForegroundColor Yellow
}

if (-not (Test-Path $fichierGlobal)) {
    Write-Host ""
    Write-Host "Tests interrompus : config globale absente" -ForegroundColor Red
    exit 1
}

# 2. Lecture config globale
Write-Host ""
Write-Host "[2] Lecture config globale" -ForegroundColor Cyan
$tmpRead = [System.IO.Path]::GetTempFileName() + ".xlsx"
Copy-Item $fichierGlobal $tmpRead -Force
$pkg = Open-ExcelPackage -Path $tmpRead
$ws = $pkg.Workbook.Worksheets["Paramètres"]
$cfgGlobal = @{}
$row = 2
while ($ws.Cells[$row, 1].Value) {
    $key = [string]$ws.Cells[$row, 1].Value
    if ($key -notmatch '^\s*--') {
        $val = $ws.Cells[$row, 2].Value
        if ($null -ne $val -and "$val" -ne '') { $cfgGlobal[$key] = $val }
    }
    $row++
}
Close-ExcelPackage $pkg -NoSave
Remove-Item $tmpRead -Force -ErrorAction SilentlyContinue

Test-Result "Config globale lisible" $true "$($cfgGlobal.Count) clé(s) trouvée(s)"

foreach ($k in $ClesGlobalesAttendues) {
    Test-Result "Clé globale '$k' présente" $cfgGlobal.ContainsKey($k)
}

# 3. SMTP joignable
Write-Host ""
Write-Host "[3] Connectivité SMTP" -ForegroundColor Cyan
if ($cfgGlobal.ContainsKey('ServeurSMTP') -and $cfgGlobal.ContainsKey('PortSMTP')) {
    $smtpHost = [string]$cfgGlobal['ServeurSMTP']
    $smtpPort = [int]$cfgGlobal['PortSMTP']
    try {
        $tn = Test-NetConnection -ComputerName $smtpHost -Port $smtpPort -WarningAction SilentlyContinue
        Test-Result "Serveur SMTP joignable ($smtpHost:$smtpPort)" $tn.TcpTestSucceeded
    } catch {
        Test-Result "Serveur SMTP joignable ($smtpHost:$smtpPort)" $false $_.Exception.Message
    }
} else {
    Test-Result "Test SMTP" $false "ServeurSMTP ou PortSMTP manquant en config globale"
}

# 4. Squads
Write-Host ""
Write-Host "[4] Squads détectées" -ForegroundColor Cyan
$squads = @()
if (Test-Path $DossierRacine) {
    $squads = Get-ChildItem -Path $DossierRacine -Directory | Where-Object {
        $_.Name -notmatch '^_' -and (Test-Path (Join-Path $_.FullName "suivi_exploitation.xlsm"))
    }
}
Test-Result "Au moins une squad" ($squads.Count -gt 0) "$($squads.Count) squad(s) détectée(s)"

# 5. Pour chaque squad
foreach ($squad in $squads) {
    Write-Host ""
    Write-Host "[5] Squad '$($squad.Name)'" -ForegroundColor Cyan
    $fichier = Join-Path $squad.FullName "suivi_exploitation.xlsm"

    try {
        $tmpSq = [System.IO.Path]::GetTempFileName() + ".xlsm"
        Copy-Item $fichier $tmpSq -Force
        $pkg = Open-ExcelPackage -Path $tmpSq
        $wsParams  = $pkg.Workbook.Worksheets['Paramètres']
        $wsMembres = $pkg.Workbook.Worksheets['Membres']

        # Lecture params locaux
        $cfgLocal = @{}
        $row = 2
        while ($wsParams.Cells[$row, 1].Value) {
            $key = [string]$wsParams.Cells[$row, 1].Value
            if ($key -notmatch '^\s*--') {
                $val = $wsParams.Cells[$row, 2].Value
                if ($null -ne $val -and "$val" -ne '') { $cfgLocal[$key] = $val }
            }
            $row++
        }
        Test-Result "  Lecture fichier squad" $true "$($cfgLocal.Count) clé(s) locale(s)"

        # Fusion
        $fusion = @{}
        foreach ($k in $cfgGlobal.Keys) { $fusion[$k] = $cfgGlobal[$k] }
        foreach ($k in $cfgLocal.Keys)  { $fusion[$k] = $cfgLocal[$k] }

        $manquantes = @($ClesObligatoiresFusion | Where-Object { -not $fusion.ContainsKey($_) })
        $detailManq = if ($manquantes.Count -gt 0) { "Manquantes : $($manquantes -join ', ')" } else { "OK" }
        Test-Result "  Toutes clés obligatoires présentes après fusion" ($manquantes.Count -eq 0) $detailManq

        # Membres actifs
        $devActifs = 0; $poActifs = 0
        $row = 2
        while ($wsMembres.Cells[$row, 1].Value) {
            $role = [string]$wsMembres.Cells[$row, 3].Value
            $actif = [string]$wsMembres.Cells[$row, 6].Value
            if ($actif -eq 'Oui') {
                if ($role -eq 'Dev') { $devActifs++ }
                elseif ($role -eq 'PO') { $poActifs++ }
            }
            $row++
        }
        Test-Result "  Au moins 1 Dev actif" ($devActifs -ge 1) "$devActifs Dev actif(s)"
        Test-Result "  Au moins 1 PO actif" ($poActifs -ge 1) "$poActifs PO actif(s)"
        if ($devActifs -lt 2) {
            Write-Host "         WARN : moins de 2 Devs actifs - règle 'pas 2x d'affilée' impossible à respecter" -ForegroundColor Yellow
        }
        if ($poActifs -lt 2) {
            Write-Host "         WARN : moins de 2 POs actifs - règle 'pas 2x d'affilée' impossible à respecter" -ForegroundColor Yellow
        }

        Close-ExcelPackage $pkg -NoSave
        Remove-Item $tmpSq -Force -ErrorAction SilentlyContinue
    }
    catch {
        Test-Result "  Lecture fichier squad" $false $_.Exception.Message
    }
}

# Récapitulatif
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " RÉCAPITULATIF" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  OK : $nbOk" -ForegroundColor Green
$colorKo = if ($nbKo -eq 0) { 'Green' } else { 'Red' }
Write-Host "  KO : $nbKo" -ForegroundColor $colorKo
Write-Host ""

if ($nbKo -gt 0) { exit 1 } else { exit 0 }
