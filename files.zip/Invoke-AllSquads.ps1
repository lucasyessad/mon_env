<#
.SYNOPSIS
    Orchestrateur multi-squads. Boucle sur tous les sous-dossiers et lance le job par squad.

.DESCRIPTION
    Architecture attendue :
        <DossierRacine>\
            _config\parametres_globaux.xlsx
            _logs\
            _scripts\Invoke-SuiviExploitation.ps1
            paiement\suivi_exploitation.xlsm
            catalogue\suivi_exploitation.xlsm
            ...

    Les sous-dossiers commençant par '_' sont ignorés (réservés à la config / logs / scripts / archives).

    Exécution :
        - Liste les squads
        - Pour chacune, lance Invoke-SuiviExploitation.ps1 dans un try/catch isolé
        - Compile un rapport (texte + HTML)
        - Écrit le rapport dans _logs\orchestrateur_<timestamp>.log
        - Si ≥1 erreur ou warning : envoie un mail récapitulatif

.PARAMETER Mode
    'Annonce' (vendredi) ou 'Rappel' (lundi)

.PARAMETER DossierRacine
    Chemin racine contenant _config\, _logs\, _scripts\ et les dossiers squads
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][ValidateSet('Annonce','Rappel')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$DossierRacine
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not (Test-Path $DossierRacine)) { throw "DossierRacine introuvable : $DossierRacine" }

$dossierConfig    = Join-Path $DossierRacine "_config"
$dossierLogs      = Join-Path $DossierRacine "_logs"
$dossierScripts   = Join-Path $DossierRacine "_scripts"
$fichierGlobal    = Join-Path $dossierConfig "parametres_globaux.xlsx"
$scriptSquad      = Join-Path $dossierScripts "Invoke-SuiviExploitation.ps1"

if (-not (Test-Path $fichierGlobal))  { throw "Fichier global introuvable : $fichierGlobal" }
if (-not (Test-Path $scriptSquad))    { throw "Script squad introuvable : $scriptSquad" }
if (-not (Test-Path $dossierLogs))    { New-Item -ItemType Directory -Path $dossierLogs -Force | Out-Null }

$ts = (Get-Date).ToString('yyyy-MM-dd_HHmmss')
$logPath = Join-Path $dossierLogs "orchestrateur_${Mode}_${ts}.log"

function Write-OrchLog([string]$line) {
    $stamp = "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))] $line"
    Write-Host $stamp
    Add-Content -Path $logPath -Value $stamp -Encoding UTF8
}

Write-OrchLog "=== Orchestrateur démarré : Mode=$Mode Racine=$DossierRacine ==="

# ============================================================
# DÉTECTION DES SQUADS
# ============================================================
$squads = Get-ChildItem -Path $DossierRacine -Directory | Where-Object {
    $_.Name -notmatch '^_' -and (Test-Path (Join-Path $_.FullName "suivi_exploitation.xlsm"))
}

if ($squads.Count -eq 0) {
    Write-OrchLog "Aucune squad trouvée. Fin."
    exit 0
}

Write-OrchLog "Squads détectées : $($squads.Count) [$(($squads | ForEach-Object { $_.Name }) -join ', ')]"

# ============================================================
# TRAITEMENT PAR SQUAD
# ============================================================
$resultats = @()

foreach ($squad in $squads) {
    $nomSquad = $squad.Name
    $fichier = Join-Path $squad.FullName "suivi_exploitation.xlsm"
    Write-OrchLog "--- Squad : $nomSquad ---"

    $resSquad = [PSCustomObject]@{
        Squad   = $nomSquad
        Statut  = 'INCONNU'
        Detail  = ''
        DevDes  = ''
        PoDes   = ''
    }

    try {
        # Capture de la sortie standard pour récupérer la ligne de résultat
        $output = & $scriptSquad -Mode $Mode -FichierExcel $fichier -FichierConfigGlobal $fichierGlobal 2>&1

        # Parse la dernière ligne de type "DESIGNATION_OK|...|...", "RAPPEL_OK|...|...", etc.
        $resultLines = @($output | Where-Object {
            $_ -is [string] -and $_ -match '^(DESIGNATION_OK|DESIGNATION_ALERTE|RAPPEL_OK|RAPPEL_SKIP|ERREUR)\|'
        })

        if ($resultLines.Count -gt 0) {
            $line = [string]$resultLines[-1]
            $parts = $line -split '\|'
            switch ($parts[0]) {
                'DESIGNATION_OK' {
                    $resSquad.Statut = 'OK'
                    $resSquad.DevDes = $parts[1]
                    $resSquad.PoDes  = $parts[2]
                    $resSquad.Detail = "Dev=$($parts[1]) / PO=$($parts[2])"
                }
                'DESIGNATION_ALERTE' {
                    $resSquad.Statut = 'ALERTE'
                    $resSquad.Detail = "$($parts[1]) | $($parts[2])"
                }
                'RAPPEL_OK' {
                    $resSquad.Statut = 'OK'
                    $resSquad.DevDes = $parts[1]
                    $resSquad.PoDes  = $parts[2]
                    $resSquad.Detail = "Rappel envoyé : Dev=$($parts[1]) / PO=$($parts[2])"
                }
                'RAPPEL_SKIP' {
                    $resSquad.Statut = 'WARN'
                    $resSquad.Detail = $parts[1]
                }
                'ERREUR' {
                    $resSquad.Statut = 'ERREUR'
                    $resSquad.Detail = $parts[1]
                }
            }
        } else {
            $resSquad.Statut = 'INCONNU'
            $resSquad.Detail = 'Aucune ligne de résultat parsable. Vérifier journal squad.'
        }
        Write-OrchLog "  $nomSquad : $($resSquad.Statut) - $($resSquad.Detail)"
    }
    catch {
        $resSquad.Statut = 'ERREUR'
        $resSquad.Detail = $_.Exception.Message
        Write-OrchLog "  $nomSquad : ERREUR - $($_.Exception.Message)"
    }

    $resultats += $resSquad
}

# ============================================================
# RAPPORT FINAL
# ============================================================
$nbOk      = @($resultats | Where-Object { $_.Statut -eq 'OK' }).Count
$nbWarn    = @($resultats | Where-Object { $_.Statut -eq 'WARN' }).Count
$nbAlerte  = @($resultats | Where-Object { $_.Statut -eq 'ALERTE' }).Count
$nbErreur  = @($resultats | Where-Object { $_.Statut -eq 'ERREUR' }).Count
$nbInconnu = @($resultats | Where-Object { $_.Statut -eq 'INCONNU' }).Count

Write-OrchLog "=== RÉCAPITULATIF ==="
Write-OrchLog "  OK      : $nbOk"
Write-OrchLog "  WARN    : $nbWarn"
Write-OrchLog "  ALERTE  : $nbAlerte"
Write-OrchLog "  ERREUR  : $nbErreur"
Write-OrchLog "  INCONNU : $nbInconnu"
Write-OrchLog "Log : $logPath"

# ============================================================
# RÉTENTION DES LOGS ORCHESTRATEUR (4 semaines)
# ============================================================
$limite = (Get-Date).AddDays(-28)
Get-ChildItem -Path $dossierLogs -File -Filter "orchestrateur_*.log" | Where-Object {
    $_.LastWriteTime -lt $limite
} | ForEach-Object {
    Remove-Item -Path $_.FullName -Force
    Write-OrchLog "Log purgé : $($_.Name)"
}

# ============================================================
# MAIL D'ALERTE SI ANOMALIES
# ============================================================
if (($nbWarn + $nbAlerte + $nbErreur + $nbInconnu) -gt 0) {
    try {
        # Lire la config globale pour SMTP + destinataires alerte
        $tmpRead = [System.IO.Path]::GetTempFileName() + ".xlsx"
        Copy-Item -Path $fichierGlobal -Destination $tmpRead -Force
        Import-Module ImportExcel -ErrorAction Stop
        $pkg = Open-ExcelPackage -Path $tmpRead
        $ws = $pkg.Workbook.Worksheets["Paramètres"]
        $cfg = @{}
        $row = 2
        while ($ws.Cells[$row, 1].Value) {
            $key = [string]$ws.Cells[$row, 1].Value
            if ($key -notmatch '^\s*--') {
                $val = $ws.Cells[$row, 2].Value
                if ($null -ne $val -and "$val" -ne '') { $cfg[$key] = $val }
            }
            $row++
        }
        Close-ExcelPackage $pkg -NoSave
        Remove-Item $tmpRead -Force -ErrorAction SilentlyContinue

        $destinataires = @()
        if ($cfg.ContainsKey('EmailsAlerteOrchestrateur')) {
            $destinataires = @([string]$cfg['EmailsAlerteOrchestrateur'] -split '\s*;\s*' | Where-Object { $_ })
        }
        if ($destinataires.Count -eq 0) {
            Write-OrchLog "Pas de destinataires d'alerte configurés. Mail non envoyé."
        } else {
            # Construction du HTML
            $rows = ""
            foreach ($r in $resultats) {
                $color = switch ($r.Statut) {
                    'OK'      { '#2E7D32' }
                    'WARN'    { '#F57C00' }
                    'ALERTE'  { '#D32F2F' }
                    'ERREUR'  { '#B71C1C' }
                    default   { '#888888' }
                }
                $rows += "<tr><td style='padding:6px 12px; border:1px solid #ccc;'>$($r.Squad)</td><td style='padding:6px 12px; border:1px solid #ccc; color:$color; font-weight:bold;'>$($r.Statut)</td><td style='padding:6px 12px; border:1px solid #ccc;'>$($r.Detail)</td></tr>"
            }
            $body = @"
<html><body style='font-family:Calibri,Arial,sans-serif; font-size:11pt;'>
<p>Bonjour,</p>
<p>L'orchestrateur de suivi d'exploitation (mode <b>$Mode</b>) a rencontré des anomalies sur au moins une squad.</p>
<p>Récapitulatif :</p>
<ul>
  <li>OK : $nbOk</li>
  <li>WARN : $nbWarn</li>
  <li>ALERTE (désignation impossible) : $nbAlerte</li>
  <li>ERREUR (exception script) : $nbErreur</li>
  <li>INCONNU : $nbInconnu</li>
</ul>
<table style='border-collapse:collapse; border:1px solid #999;'>
  <tr style='background:#2F5496; color:white;'><th style='padding:6px 12px;'>Squad</th><th style='padding:6px 12px;'>Statut</th><th style='padding:6px 12px;'>Détail</th></tr>
  $rows
</table>
<p style='color:#888; font-size:9pt;'>Log complet : $logPath</p>
</body></html>
"@
            $smtp = New-Object System.Net.Mail.SmtpClient
            $smtp.Host = [string]$cfg['ServeurSMTP']
            $smtp.Port = [int]$cfg['PortSMTP']
            if ($cfg['SMTP_UseSSL'] -eq 'Oui' -or $cfg['SMTP_UseTLS'] -eq 'Oui') { $smtp.EnableSsl = $true }

            $msg = New-Object System.Net.Mail.MailMessage
            if ($cfg.ContainsKey('EmailExpediteurOrchestrateur')) {
                $expediteur = [string]$cfg['EmailExpediteurOrchestrateur']
            } else {
                throw "Clé 'EmailExpediteurOrchestrateur' manquante dans parametres_globaux.xlsx"
            }
            $msg.From = New-Object System.Net.Mail.MailAddress($expediteur, "Orchestrateur Suivi Exploitation")
            foreach ($d in $destinataires) { $msg.To.Add($d) }
            $msg.Subject = "[Orchestrateur Suivi Exploitation] $Mode - $nbErreur erreur(s) / $nbAlerte alerte(s) / $nbWarn warning(s)"
            $msg.Body = $body
            $msg.IsBodyHtml = $true
            $msg.BodyEncoding = [System.Text.Encoding]::UTF8
            $msg.SubjectEncoding = [System.Text.Encoding]::UTF8
            $smtp.Send($msg)
            $msg.Dispose()
            Write-OrchLog "Mail récapitulatif envoyé à : $($destinataires -join ', ')"
        }
    }
    catch {
        Write-OrchLog "ERREUR envoi mail récapitulatif : $($_.Exception.Message)"
    }
}

# Code de sortie : 0 si tout OK, 1 sinon
if (($nbAlerte + $nbErreur + $nbInconnu) -gt 0) { exit 1 } else { exit 0 }
