<#
.SYNOPSIS
    Crée un nouveau dossier squad pré-rempli, prêt pour la mise en route.

.DESCRIPTION
    Étapes :
      1. Demande interactive : nom de la squad, responsables, copies, expéditeur
      2. Crée le sous-dossier <DossierRacine>\<nom_squad>\
      3. Copie le template suivi_exploitation_template.xlsx -> suivi_exploitation.xlsx
      4. Pré-remplit la feuille Paramètres avec les valeurs saisies
      5. Affiche les étapes manuelles restantes (import VBA, conversion .xlsm, ajout à Task Scheduler N/A car orchestrateur)

.PARAMETER DossierRacine
    Chemin racine multi-squads

.PARAMETER Template
    Chemin du template suivi_exploitation_template.xlsx (par défaut : <DossierRacine>\_config\suivi_exploitation_template.xlsx)

.EXAMPLE
    .\New-SquadFolder.ps1 -DossierRacine "\\srv\suivi-exploitation"
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string]$DossierRacine,
    [string]$Template
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not (Test-Path $DossierRacine)) { throw "DossierRacine introuvable : $DossierRacine" }
if (-not $Template) {
    $Template = Join-Path $DossierRacine "_config\suivi_exploitation_template.xlsx"
}
if (-not (Test-Path $Template)) { throw "Template introuvable : $Template" }

if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber
}
Import-Module ImportExcel

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CRÉATION D'UNE NOUVELLE SQUAD" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

function Read-Required([string]$prompt) {
    while ($true) {
        $v = Read-Host $prompt
        if ($v -and $v.Trim()) { return $v.Trim() }
        Write-Host "  -> Valeur obligatoire" -ForegroundColor Yellow
    }
}

# Saisie
$nomDossier = Read-Required "Nom du dossier squad (ex: 'paiement', 'catalogue') - sera utilisé comme nom de dossier"
if ($nomDossier -match '^[_]') { throw "Le nom de dossier ne peut pas commencer par '_'" }
if ($nomDossier -match '[\\/:*?"<>|]') { throw "Caractères interdits dans le nom de dossier" }

$nomSquad        = Read-Required "Nom affiché de la squad (ex: 'Squad Paiement')"
$emailExpediteur = Read-Required "Email expéditeur (ex: 'suivi-paiement@entreprise.fr')"
$nomExpediteur   = Read-Host "Nom expéditeur affiché [défaut: 'Suivi Exploitation - $nomSquad']"
if (-not $nomExpediteur) { $nomExpediteur = "Suivi Exploitation - $nomSquad" }
$respDev = Read-Required "Email du responsable Dev (fallback)"
$respPo  = Read-Required "Email du responsable PO (fallback)"
$copies  = Read-Host "Emails en copie (séparateur ';' ; vide = tous les membres actifs)"

# Création du dossier
$cibleDossier = Join-Path $DossierRacine $nomDossier
if (Test-Path $cibleDossier) {
    Write-Host ""
    Write-Host "  ATTENTION : le dossier '$cibleDossier' existe déjà." -ForegroundColor Yellow
    $rep = Read-Host "Continuer et écraser le fichier suivi_exploitation.xlsx ? (o/N)"
    if ($rep -ne 'o' -and $rep -ne 'O') {
        Write-Host "Annulé." -ForegroundColor Yellow
        exit 0
    }
} else {
    New-Item -ItemType Directory -Path $cibleDossier -Force | Out-Null
}

# Copie du template
$cibleFichier = Join-Path $cibleDossier "suivi_exploitation.xlsx"
Copy-Item -Path $Template -Destination $cibleFichier -Force
Write-Host ""
Write-Host "  + Dossier créé   : $cibleDossier" -ForegroundColor Green
Write-Host "  + Template copié : $cibleFichier" -ForegroundColor Green

# Pré-remplissage
$pkg = Open-ExcelPackage -Path $cibleFichier
$ws = $pkg.Workbook.Worksheets["Paramètres"]

# La structure du template :
# Ligne 1 : header
# Ligne 2 : -- PARAMÈTRES OBLIGATOIRES --
# Lignes 3-8 : NomSquad, EmailExpediteur, NomExpediteur, ResponsableDev, ResponsablePO, EmailsCopieSquad
$mapping = @{
    'NomSquad'         = $nomSquad
    'EmailExpediteur'  = $emailExpediteur
    'NomExpediteur'    = $nomExpediteur
    'ResponsableDev'   = $respDev
    'ResponsablePO'    = $respPo
    'EmailsCopieSquad' = $copies
}

$row = 2
$updated = 0
while ($ws.Cells[$row, 1].Value) {
    $key = [string]$ws.Cells[$row, 1].Value
    if ($mapping.ContainsKey($key)) {
        $ws.Cells[$row, 2].Value = $mapping[$key]
        $updated++
    }
    $row++
}
Close-ExcelPackage $pkg

Write-Host "  + $updated paramètre(s) renseigné(s) dans la feuille Paramètres" -ForegroundColor Green

# Création du dossier historique
$histPath = Join-Path $cibleDossier "historique"
if (-not (Test-Path $histPath)) { New-Item -ItemType Directory -Path $histPath -Force | Out-Null }
Write-Host "  + Dossier historique créé : $histPath" -ForegroundColor Green

# Étapes manuelles
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ÉTAPES MANUELLES RESTANTES" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Ouvrir $cibleFichier dans Excel" -ForegroundColor White
Write-Host "2. Alt+F11 -> Importer mdlSuiviExploitation.bas" -ForegroundColor White
Write-Host "3. Coller le code ThisWorkbook (cf. ThisWorkbook_CodeAColler.txt)" -ForegroundColor White
Write-Host "4. Enregistrer en .xlsm puis supprimer le .xlsx" -ForegroundColor White
Write-Host "5. Compléter la feuille 'Membres' avec les membres de la squad" -ForegroundColor White
Write-Host ""
Write-Host "Aucune action sur Task Scheduler : l'orchestrateur prendra automatiquement" -ForegroundColor Green
Write-Host "cette nouvelle squad au prochain run (vendredi/lundi 6h)." -ForegroundColor Green
Write-Host ""
