# Suivi d'Exploitation Multi-Squads — Installation & Exploitation

Système de désignation hebdomadaire automatique d'un dev + un PO pour le suivi d'exploitation, **scalable à plusieurs squads** dans la même entreprise.

---

## Architecture

```
\\srv-fichiers\suivi-exploitation\         ← DossierRacine
│
├── _config\
│   ├── parametres_globaux.xlsx            ← SMTP entreprise + templates de mail
│   └── suivi_exploitation_template.xlsx   ← Template pour onboarding nouvelles squads
│
├── _scripts\
│   ├── Invoke-AllSquads.ps1               ← Orchestrateur (appelé par Task Scheduler)
│   ├── Invoke-SuiviExploitation.ps1       ← Job d'une squad (appelé par l'orchestrateur)
│   ├── New-SquadFolder.ps1                ← Onboarding nouvelle squad
│   └── Test-Configuration.ps1             ← Vérif avant mise en prod
│
├── _logs\                                  ← Logs orchestrateur (créé automatiquement)
│
├── paiement\                               ← 1 dossier par squad
│   ├── suivi_exploitation.xlsm            ← Membres, congés, historique, params LOCAUX
│   └── historique\                         ← Versions datées (rétention 4 semaines)
│
├── catalogue\
│   ├── suivi_exploitation.xlsm
│   └── historique\
│
└── livraison\
    ├── suivi_exploitation.xlsm
    └── historique\
```

**2 tâches planifiées au total** pour TOUTES les squads :
- Vendredi 6h00 → orchestrateur en mode `Annonce`
- Lundi 6h00 → orchestrateur en mode `Rappel`

L'ajout d'une nouvelle squad ne nécessite **aucune intervention sur Task Scheduler**.

---

## Principe de configuration : Globale + Locale

### Paramètres globaux (`_config\parametres_globaux.xlsx`)

Communs à toute l'entreprise :
- `ServeurSMTP`, `PortSMTP`, `SMTP_UseTLS`, `SMTP_UseSSL`
- `SujetAnnonce`, `SujetRappel`, `SujetAlerte` (templates par défaut)
- `EmailsAlerteOrchestrateur`, `EmailExpediteurOrchestrateur`

### Paramètres locaux (`<squad>\suivi_exploitation.xlsm`, feuille Paramètres)

Spécifiques à la squad :
- `NomSquad`, `EmailExpediteur`, `NomExpediteur`
- `ResponsableDev`, `ResponsablePO`
- `EmailsCopieSquad`

### Fusion

Pour chaque squad : config globale lue **en premier**, puis surchargée par config locale. Si une squad veut son propre `SujetAnnonce`, elle l'ajoute simplement dans sa feuille Paramètres.

Si une clé obligatoire manque dans les **deux** fichiers : le job s'arrête avec une erreur explicite.

---

## Prérequis

- Windows 10/11 ou Windows Server 2016+
- PowerShell 5.1+ (natif)
- Excel 2016+ pour ouvrir/éditer les fichiers
- Compte de service avec accès lecture/écriture sur `<DossierRacine>\`
- Accès SMTP interne (anonyme par défaut sur port 25)

Le module PowerShell `ImportExcel` s'installe automatiquement au premier lancement (scope utilisateur, sans droits admin).

---

## Installation initiale

### Étape 1 — Créer la structure de dossiers

Sur le partage réseau :

```powershell
# Créer la racine et les sous-dossiers techniques
New-Item -ItemType Directory -Path "\\srv-fichiers\suivi-exploitation\_config" -Force
New-Item -ItemType Directory -Path "\\srv-fichiers\suivi-exploitation\_scripts" -Force
New-Item -ItemType Directory -Path "\\srv-fichiers\suivi-exploitation\_logs" -Force
```

### Étape 2 — Déployer les fichiers

| Fichier source | Destination |
|---|---|
| `parametres_globaux.xlsx` | `\\srv\suivi-exploitation\_config\` |
| `suivi_exploitation_template.xlsx` | `\\srv\suivi-exploitation\_config\` |
| `Invoke-AllSquads.ps1` | `\\srv\suivi-exploitation\_scripts\` |
| `Invoke-SuiviExploitation.ps1` | `\\srv\suivi-exploitation\_scripts\` |
| `New-SquadFolder.ps1` | `\\srv\suivi-exploitation\_scripts\` |
| `Test-Configuration.ps1` | `\\srv\suivi-exploitation\_scripts\` |
| `mdlSuiviExploitation.bas` | `\\srv\suivi-exploitation\_config\` (référence) |
| `ThisWorkbook_CodeAColler.txt` | `\\srv\suivi-exploitation\_config\` (référence) |

### Étape 3 — Configurer la config globale

Ouvrir `\\srv\suivi-exploitation\_config\parametres_globaux.xlsx`, feuille **Paramètres** :

| Clé | Exemple |
|---|---|
| `ServeurSMTP` | `smtp.entreprise.fr` |
| `PortSMTP` | `25` |
| `SMTP_UseTLS` | `Non` |
| `SMTP_UseSSL` | `Non` |
| `SujetAnnonce` | `[Suivi Exploitation {Squad}] Semaine du {DateLundi} - Désignation` |
| `SujetRappel` | `[Suivi Exploitation {Squad}] Rappel - Semaine du {DateLundi}` |
| `SujetAlerte` | `[Suivi Exploitation {Squad}] ALERTE - Pas de désignation possible` |
| `EmailsAlerteOrchestrateur` | `admin1@entreprise.fr;admin2@entreprise.fr` |
| `EmailExpediteurOrchestrateur` | `orchestrateur-suivi@entreprise.fr` |

Recommandation : restreindre l'écriture de ce fichier au niveau ACL Windows (admin uniquement).

### Étape 4 — Onboarder la première squad

```powershell
cd \\srv-fichiers\suivi-exploitation\_scripts
.\New-SquadFolder.ps1 -DossierRacine "\\srv-fichiers\suivi-exploitation"
```

Suivre les prompts. Le script :
1. Crée le sous-dossier squad
2. Copie le template Excel
3. Pré-remplit la feuille Paramètres avec les valeurs saisies
4. Crée le sous-dossier `historique\`

### Étape 5 — Activer les macros dans le fichier squad

À refaire pour **chaque** fichier squad (une seule fois par squad) :

1. Ouvrir `<squad>\suivi_exploitation.xlsx` dans Excel
2. `Alt+F11` → ouvre VBE
3. **Importer le module** : `Fichier` → `Importer un fichier…` → sélectionner `mdlSuiviExploitation.bas`
4. **Coller le code ThisWorkbook** : double-cliquer sur `ThisWorkbook` dans l'arborescence, copier-coller le contenu de `ThisWorkbook_CodeAColler.txt`
5. **Enregistrer en .xlsm** : `Fichier` → `Enregistrer sous` → type `Classeur Excel (prenant en charge les macros) (*.xlsm)`. Supprimer le `.xlsx` d'origine.
6. **Compléter la feuille `Membres`** avec les membres de la squad (Nom, Email, Rôle, Actif=Oui)
7. (Optionnel) Lier un vrai bouton à la zone "AJOUTER UN CONGÉ" : onglet `Développeur` → `Insérer` → `Bouton de formulaire` → dessiner par-dessus la zone verte → affecter la macro `AjouterConge`

> Le raccourci `Ctrl+Shift+C` est activé automatiquement à l'ouverture du fichier après installation VBA — il fonctionne sans bouton physique.

### Étape 6 — Tester la configuration

```powershell
cd \\srv-fichiers\suivi-exploitation\_scripts
.\Test-Configuration.ps1 -DossierRacine "\\srv-fichiers\suivi-exploitation"
```

Le script vérifie :
- Structure de dossiers
- Présence de toutes les clés globales attendues
- Connectivité SMTP (Test-NetConnection)
- Pour chaque squad : fichier lisible, fusion des paramètres OK, au moins 1 Dev actif et 1 PO actif

**Tous les tests doivent être verts avant de passer à l'étape 7.**

### Étape 7 — Configurer les 2 tâches planifiées

#### Option A — Import des XML

1. Éditer `SuiviExploitation_AllSquads_Annonce.xml` et `SuiviExploitation_AllSquads_Rappel.xml`
2. Remplacer `<DOSSIER_RACINE>` et `<DOMAINE\compte_service>`
3. Importer dans Task Scheduler (`taskschd.msc` → Importer une tâche)

#### Option B — Création PowerShell

```powershell
$racine = "\\srv-fichiers\suivi-exploitation"
$compte = "DOMAINE\compte_service"

# Annonce - vendredi 6h
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$racine\_scripts\Invoke-AllSquads.ps1`" -Mode Annonce -DossierRacine `"$racine`""
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Friday -At 06:00
Register-ScheduledTask -TaskName "SuiviExploitation_AllSquads_Annonce" `
    -Action $action -Trigger $trigger -User $compte -RunLevel Highest

# Rappel - lundi 6h
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$racine\_scripts\Invoke-AllSquads.ps1`" -Mode Rappel -DossierRacine `"$racine`""
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 06:00
Register-ScheduledTask -TaskName "SuiviExploitation_AllSquads_Rappel" `
    -Action $action -Trigger $trigger -User $compte -RunLevel Highest
```

### Étape 8 — Test manuel

```powershell
cd \\srv-fichiers\suivi-exploitation\_scripts
.\Invoke-AllSquads.ps1 -Mode Annonce -DossierRacine "\\srv-fichiers\suivi-exploitation"
```

Vérifier :
- Sortie console montre toutes les squads avec leur statut
- Fichier de log généré dans `_logs\orchestrateur_Annonce_<timestamp>.log`
- Pour chaque squad : ligne ajoutée dans `Historique`, `DateDernierSuivi` mise à jour dans `Membres`
- Une copie datée dans `<squad>\historique\`
- Mail reçu par les destinataires

---

## Opérations courantes

### Ajouter une nouvelle squad

```powershell
.\_scripts\New-SquadFolder.ps1 -DossierRacine "\\srv-fichiers\suivi-exploitation"
```

Puis faire l'étape 5 (import VBA) sur le nouveau fichier.

**Aucune action sur Task Scheduler.** L'orchestrateur la prend automatiquement au prochain run.

### Retirer une squad temporairement

Renommer son dossier en `_archive_<nom>` (préfixe `_` = ignoré par l'orchestrateur).

### Mettre à jour le SMTP entreprise

Modifier uniquement `_config\parametres_globaux.xlsx`. Toutes les squads bénéficient du changement au prochain run.

### Modifier le sujet des mails pour UNE squad

Ajouter la clé `SujetAnnonce` (ou autre) dans la feuille Paramètres de cette squad. La valeur locale gagne sur la valeur globale.

### Ajouter un membre dans une squad

Ouvrir `<squad>\suivi_exploitation.xlsm` → feuille Membres → nouvelle ligne avec Nom/Email/Rôle/Actif=Oui. **Laisser DateDernierSuivi et Compteur vides** : initialisation auto à la médiane.

### Désactiver un membre

Passer `Actif` = `Non`. Ne pas supprimer la ligne (on garde l'historique).

---

## Logs et audit

| Endroit | Contenu |
|---|---|
| `_logs\orchestrateur_<Mode>_<ts>.log` | Récap d'un run orchestrateur (rétention 4 semaines) |
| `<squad>\suivi_exploitation.journal.log` | Journal texte par squad (append-only) |
| Feuille `Log` du fichier squad | 1000 dernières entrées (rolling) |
| Feuille `Historique` | Désignations hebdomadaires |
| `<squad>\historique\` | Versions datées des fichiers (rétention 4 semaines) |

---

## Troubleshooting

| Symptôme | Cause | Résolution |
|---|---|---|
| `Test-Configuration` échoue sur SMTP | Firewall ou port fermé | Vérifier auprès DSI / réseau |
| `Test-Configuration` : "Clé X manquante" | Config globale ou locale incomplète | Compléter la feuille Paramètres |
| Une squad échoue : "Fichier ouvert" | Quelqu'un a Excel ouvert sur ce fichier au moment du run | Fermer Excel, relancer manuellement |
| Toutes les squads échouent | Souvent : config globale mal lue ou SMTP HS | Lancer Test-Configuration |
| Un mail récap arrive avec WARN/ALERTE | Désignation impossible sur une ou plusieurs squads | Cliquer sur le mail, voir la colonne Détail, désigner manuellement dans Historique |
| Le `.lock` reste après crash | Crash inattendu | Le supprimer manuellement, vérifier `journal.log` |
| Ctrl+Shift+C ne marche pas | Conflit avec un add-in Excel | Modifier le raccourci dans `mdlSuiviExploitation.bas` ligne `Application.OnKey "+^c"` |
| Mail récap reçu avec un statut INCONNU | Le job squad a planté avant d'écrire son statut de sortie | Voir `<squad>\suivi_exploitation.journal.log` pour la stack trace |

---

## Limitations connues

1. **SMTP authentifié non géré** : si l'auth devient nécessaire, modifier `Send-Mail` dans `Invoke-SuiviExploitation.ps1` et `Invoke-AllSquads.ps1` pour utiliser `Get-StoredCredential` (module CredentialManager) ou un SecureString chiffré DPAPI.
2. **Congés demi-journées non gérés** : 1 jour de congé = jour entier.
3. **Jours fériés non gérés** : si lundi férié, désignation faite normalement.
4. **Concurrence** : un fichier = une squad. Ne pas mutualiser.
5. **Rétention fixe à 4 semaines** : modifier les variables `(Get-Date).AddDays(-28)` dans `Invoke-SuiviExploitation.ps1` et `Invoke-AllSquads.ps1` pour changer.
